// Selenium test runner logic
