// Prompt input component
