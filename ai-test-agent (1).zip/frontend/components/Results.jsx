// Result display component
