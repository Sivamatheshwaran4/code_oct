import React, { useState } from "react";
import axios from "axios";

export default function App() {
  const [prompt, setPrompt] = useState("");
  const [framework, setFramework] = useState("playwright");
  const [browser, setBrowser] = useState("chrome");
  const [result, setResult] = useState([]);
  const [excelFile, setExcelFile] = useState(null);

  const generateAndRun = async () => {
    const res = await axios.post("http://localhost:4000/generate-code", {
      prompt,
      framework
    });

    const runRes = await axios.post("http://localhost:4000/run-tests", {
      codeList: [res.data.code],
      framework,
      browser
    });

    setResult(runRes.data.summary);
  };

  const uploadExcel = async () => {
    const formData = new FormData();
    formData.append("file", excelFile);
    const res = await axios.post("http://localhost:4000/upload-excel", formData);
    const steps = res.data.steps;
    const codes = await Promise.all(
      steps.map(step => axios.post("http://localhost:4000/generate-code", {
        prompt: step,
        framework
      }).then(r => r.data.code))
    );
    const runRes = await axios.post("http://localhost:4000/run-tests", {
      codeList: codes,
      framework,
      browser
    });
    setResult(runRes.data.summary);
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>🧠 AI Test Agent</h2>
      <textarea
        rows="3"
        style={{ width: "100%" }}
        placeholder="Type test prompt here..."
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
      />
      <br />
      <label>Framework:</label>
      <select value={framework} onChange={(e) => setFramework(e.target.value)}>
        <option value="playwright">Playwright (TS)</option>
        <option value="selenium">Selenium (Java)</option>
      </select>

      <label style={{ marginLeft: 10 }}>Browser:</label>
      <select value={browser} onChange={(e) => setBrowser(e.target.value)}>
        <option value="chrome">Chrome</option>
        <option value="firefox">Firefox</option>
        <option value="edge">Edge</option>
      </select>
      <br /><br />

      <button onClick={generateAndRun}>▶️ Run Prompt</button>
      <br /><br />
      <input type="file" onChange={(e) => setExcelFile(e.target.files[0])} />
      <button onClick={uploadExcel}>📂 Run Excel Test Cases</button>

      <h3>🧪 Test Results:</h3>
      <ul>
        {result.map((r, idx) => (
          <li key={idx}>
            Case {r.case}: <b>{r.status}</b>
            {r.error && <pre>{r.error}</pre>}
          </li>
        ))}
      </ul>

      <a href="http://localhost:4000/download" target="_blank">📥 Download .zip</a>
    </div>
  );
}