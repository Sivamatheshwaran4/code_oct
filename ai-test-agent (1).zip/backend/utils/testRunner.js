const fs = require('fs');
const { execSync } = require('child_process');

function executeTest(codeList, framework, browser) {
  const results = [];
  codeList.forEach((code, index) => {
    const fileName = framework === 'playwright' ? `test${index}.spec.ts` : `Test${index}.java`;
    const filePath = `./generated/${fileName}`;
    fs.writeFileSync(filePath, code);
    try {
      execSync(framework === 'playwright'
        ? `npx playwright test ${filePath}`
        : `javac ${filePath} && java ${fileName.replace('.java', '')}`);
      results.push({ case: index + 1, status: 'PASS' });
    } catch (err) {
      results.push({ case: index + 1, status: 'FAIL', error: err.message });
    }
  });
  return { summary: results };
}

module.exports = { executeTest };