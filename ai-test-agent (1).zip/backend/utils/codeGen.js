function generateCodeFromPrompt(prompt, framework) {
  if (framework === "playwright") {
    return `import { test, expect } from '@playwright/test';

test('AI generated test', async ({ page }) => {
  await page.goto('https://example.com');
  // Simulated Step: ${prompt}
  await expect(page).toHaveTitle(/Example/);
});`;
  } else if (framework === "selenium") {
    return `import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AiTest {
  public static void main(String[] args) {
    WebDriver driver = new ChromeDriver();
    driver.get("https://example.com");
    // Simulated Step: ${prompt}
    driver.quit();
  }
}`;
  }
  return "// Framework not supported";
}

module.exports = { generateCodeFromPrompt };