const fs = require('fs');
const archiver = require('archiver');

function createZip() {
  return new Promise((resolve, reject) => {
    const output = fs.createWriteStream('./ai-test-output.zip');
    const archive = archiver('zip', { zlib: { level: 9 } });

    archive.on('error', err => reject(err));
    output.on('close', () => resolve('./ai-test-output.zip'));

    archive.pipe(output);
    archive.directory('./generated/', 'generated');
    archive.finalize();
  });
}

module.exports = { createZip };