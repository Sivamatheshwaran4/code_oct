// TypeScript template for Playwright
